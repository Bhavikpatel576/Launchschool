
class Atbash
  attr_reader :string_to_decipher, :code, :alphabet

  def self.encode(string)
    new(string).encode
  end

  def initialize(string)
    @string_to_decipher = string.downcase.scan(/\b[a-z0-9]+\b/).join.chars
    code = create_hash()
  end

  def create_hash
    @alphabet = ('a'..'z').to_a
    encoding = alphabet.reverse
    @code = {}
    alphabet.each.with_index do |key, value|
      code[key] = encoding[value]
    end
    @code
  end

  def encode
    cipher = ""
    string_to_decipher.each do |el|
      if @alphabet.include?(el)
        cipher += code[el]
      else
        cipher += el
      end
    end
    massage_string(cipher)
  end

  private

  def massage_string(string)
    ciphered_text = ""
    string.chars.each.with_index do |value, idx|
      if idx % 5 == 0 && idx != 0
        ciphered_text += " "
        ciphered_text += value
      else
        ciphered_text += value
      end
    end
    ciphered_text
  end
end

require 'minitest/autorun'
require "minitest/reporters"
Minitest::Reporters.use!

require_relative 'atbash'

class AtbashTest < MiniTest::Test
  def test_encode_no
    assert_equal 'ml', Atbash.encode('no')
  end

  def test_encode_yes
    
    assert_equal 'bvh', Atbash.encode('yes')
  end

  def test_encode_OMG
    
    assert_equal 'lnt', Atbash.encode('OMG')
  end

  def test_encode_O_M_G
    
    assert_equal 'lnt', Atbash.encode('O M G')
  end

  def test_encode_long_word
    
    assert_equal 'nrmwy oldrm tob', Atbash.encode('mindblowingly')
  end

  def test_encode_numbers
    
    assert_equal('gvhgr mt123 gvhgr mt',
                 Atbash.encode('Testing, 1 2 3, testing.'))
  end

  def test_encode_sentence
    
    assert_equal 'gifgs rhurx grlm', Atbash.encode('Truth is fiction.')
  end

  def test_encode_all_the_things
    
    plaintext = 'The quick brown fox jumps over the lazy dog.'
    cipher = 'gsvjf rxpyi ldmul cqfnk hlevi gsvoz abwlt'
    assert_equal cipher, Atbash.encode(plaintext)
  end
end